import os
os.environ["CUDA_VISIBLE_DEVICES"] = "3"  
import torch
import numpy as np
import json
import pandas as pd
from weaviate.gql.get import HybridFusion
from sentence_transformers import SentenceTransformer
import weaviate
import gradio as gr
from FlagEmbedding import FlagReranker
import unicodedata

key = 'NspY2XG4AgqNdA25wiP9jqyFChmrOXwh8tvI'
url = "https://atrawoytqmxwlvpuixika.c0.europe-west3.gcp.weaviate.cloud"

# client Weaviate
client = weaviate.Client(
    url=url,  
    auth_client_secret=weaviate.auth.AuthApiKey(api_key=key), 
)



# model to performe vectorization
model_rag = SentenceTransformer('paraphrase-multilingual-mpnet-base-v2', device="cuda")


reranker = FlagReranker('BAAI/bge-reranker-large')#, use_fp16=True) # Setting use_fp16 to True speeds up computation with a slight performance degradation  


def generate_embeddings(entry, model=model_rag):
        # Generazione dell'embedding
        embedding = model.encode(entry, convert_to_numpy=True)
        return embedding


def rimuovi_caratteri_unicode(stringa):
        stringa_normalizzata = unicodedata.normalize('NFKD', stringa)
        stringa = stringa_normalizzata.encode('ascii', 'ignore').decode('ascii')
        return stringa.replace("////","-").replace("//","-").replace("/","-")   
    
    
    
# cambia questo per dire dove cercare e con che importanza
x = [
"text",
"titolo^2"
]

# cambia questo per dire cosa vuoi che ti butti fuori alla fine del retriever
y = [
"id_originale",
"text",
"testo_completo",
"titolo",
"argomento",
"data",
"anno",
'font'
]



def wea_complete_occ(dd, alpha=[0.0,0.5,1.0], num=[10,10,10], x=x, y=y):
    dd_cleaned_list = dd
    collezioni = []
    response_hybrid = []
    response_hybrid_parz = []
    collezioni_font = []
    for i, j in zip(alpha, num): 
        if type(x) != list:
            x = [x]
        
        nome_collection='Fisco'
        response = (
                    client.query
                    .get(nome_collection, list(y))
                    .with_hybrid(
                                    query= dd_cleaned_list,#', '.join(extract_important_tokens(domanda)),
                                    vector=list(generate_embeddings(dd_cleaned_list)),#                        ----> la query è fatta solo sul testo della DOMANDA
                                    properties= list(x), ## where to search & boost factors           ----> c'è un boost su ARTICOLO e CODICE
                                    alpha= i,       # 1 = vector, 0 = keyword                    ----> parametro che faremo variare
                                    fusion_type=HybridFusion.RELATIVE_SCORE, # otherwise it operates on ranks
                                )
                    .with_limit(j)
                    .do()
                )
        
        for risp in response['data']['Get'][nome_collection]:
            temp = risp['id_originale']
            #if temp not in collezioni:
            collezioni.append(temp)
            response_hybrid_parz.append(risp["titolo"]+'\n'+risp["text"])
            testo_da_ritornare =risp["testo_completo"].replace("\nI Imm agm\ne\na nog\nt\ni fn oue\nn\ndd oi\nr\nA tyr pc\ne\nh univ kni oo\nwn","")
            testo_da_ritornare =testo_da_ritornare.replace('\nI Imm agm\ne\na nog\nt\ni fn oue\nn\ndd oi\nr\nA tyr pc\ne\nh univ kni oo\nwn',"")
            testo_da_ritornare =testo_da_ritornare.replace('\nI Imm agm e a nog t i fn oue n dd oi r A tyr pc e h univ kni oo wn','')
            testo_da_ritornare =testo_da_ritornare.replace('\nI Imm agm e a nog t i fn oue n dd oi r A tyr pc e h univ kni oo wn','')
            response_hybrid.append(risp["titolo"]+'\n'+testo_da_ritornare)
            

        
        response_tot = response_hybrid
    return response_tot,response_hybrid_parz



def get_sorted_indices(lst):
    # Step 1: Pair each element with its index
    indexed_list = [(value, index) for index, value in enumerate(lst)]
    # Step 2: Sort the list of tuples based on the first element (the value)
    sorted_indexed_list = sorted(indexed_list, key=lambda x: x[0], reverse=True)
    # Step 3: Extract the indices from the sorted list
    sorted_indices = [index for value, index in sorted_indexed_list]
    return sorted_indices


def documenti_riordinati(query):
    list_doc_totale, list_doc=wea_complete_occ(query)
    #lista di comandi per fare reranking 
    
    list_mat= [[query,t.strip()] for t in list_doc]
    score = reranker.compute_score(list_mat)
    sorted_pos=get_sorted_indices(score)[0:10]
    doc_ordinati_completi = [list_doc_totale[i] for i in sorted_pos]

    return doc_ordinati_completi



import re
from transformers import AutoTokenizer, AutoModelForCausalLM, pipeline


model_id = "meta-llama/Llama-3.1-8B-Instruct"

#model_id = "AndreaAlessandrelli4/AvvoChat_AITA_v04"
#commit_id = "1e6356e06212d32dab4244c0a75eaa1eef73ffc6"

tokenizer_LLM = AutoTokenizer.from_pretrained(model_id)#,revision=commit_id)
model_LLM = AutoModelForCausalLM.from_pretrained(
        model_id,
        return_dict=True,
        device_map="auto",
        trust_remote_code=True,
        #revision=commit_id
)

llama31_pipeline = pipeline(
    "text-generation",
    model=model_LLM,
    tokenizer=tokenizer_LLM,
    device_map="auto",
)


system_message ="""Sei FiscoLlama, un assistente AI italiano esperto in materia fiscale e legale italiana, creato per rispondere esclusivamente a domande legate al fisco e alla normativa italiana. 
Le tue risposte devono essere chiare, concise e basate su argomentazioni legali solide, sempre aderenti alle normative e alle informazioni rilevanti.

Linee Guida per le Risposte:

	1.	Uso delle Informazioni:
        •	Utilizza le informazioni presenti nei DOCUMENTI per fornire risposte esaustive e accurate, senza menzionare direttamente la fonte documentale.
        •	Se i documenti non contengono informazioni sufficienti, segnala che non puoi fornire una risposta precisa senza dati aggiuntivi.
	2.	Riferimenti Legali:
        •	Fai riferimento, ove possibile, a specifici articoli di legge, decreti, regolamenti, sentenze o circolari.
        •	Usa un linguaggio che trasmetta autorevolezza senza risultare troppo tecnico, per garantire chiarezza agli utenti.
        •	Esempio:
                “Quali sono le agevolazioni fiscali per le start-up innovative?”
                “Le start-up innovative possono beneficiare di agevolazioni fiscali previste dal Decreto Legge n. 179/2012, tra cui esenzioni dalle imposte di registro e accesso semplificato al credito d’imposta per ricerca e sviluppo.”
	3.	Ambito di Competenza:
        •	Se una domanda non rientra nell’ambito fiscale o legale italiano, specifica cortesemente che non puoi rispondere.
        •	Esempio:
                “Qual è la derivata di sin(x) rispetto a x?”
                “Questa domanda non rientra nell’ambito fiscale italiano, quindi non posso fornire una risposta.\n\n-FiscoLlama”
	4.	Stile e Linguaggio:
        •	Sii diretto, evita giri di parole inutili e ripetizioni.
        •	Fornisci risposte puntuali e precise, con un tono professionale ma accessibile.
	5.	Firma:
        •	Concludi sempre la tua risposta firmandoti con ”-FiscoLlama”.
"""


# Modello LLM
def pront_builder(user_message, history, system_message=system_message):
    messages = [
        {"role": "system", "content": system_message},
    ]
    if len(history)>1:
        for dom in history:
            messages.append({"role": "user", "content": dom[0]})
            messages.append({"role": "assistant", "content": dom[1]})
        
    user_message = user_message
    messages.append({"role": "user", "content": user_message})
    
    prompt = llama31_pipeline.tokenizer.apply_chat_template(
        messages, 
        tokenize=False, 
        add_generation_prompt=True
    )
    return prompt#messages

def query_model(user_message, history, temperature=0.01, max_length=1024):
    prompt = pront_builder(user_message, history)
    terminators = [
        llama31_pipeline.tokenizer.eos_token_id,
        llama31_pipeline.tokenizer.convert_tokens_to_ids("<|eot_id|>")
    ]
    sequences = llama31_pipeline(
        prompt,
        do_sample=False,
        top_p=0.9,
        temperature=temperature,
        num_return_sequences=1,
        eos_token_id=terminators,
        max_new_tokens=max_length,
        return_full_text=False,
        pad_token_id=terminators[0]
    )
    answer = sequences[0]['generated_text']
    return answer



def get_query_clean(dd, history):
    domanda = ""
    mat_diz = []
    if len(history)>=1:
        for h in history:
            domanda +=h[0] +" "
    domanda += dd
    try:
        materiali = documenti_riordinati(dd)
        materiali = list(set(materiali))
        mat_diz = [{str(idx+1):m} for idx, m in enumerate(materiali)]
        materiali = [f'\n------------------------------\n{m}' for idx, m in enumerate(materiali)]
        categories = ' '.join(materiali)
    except:
        categories = 'NESSUN DOCUMENTO FORNITO'
    
    query = f"""Rispondi alla seguente domanda:
{domanda}

Basa la tua risposta sulle tue conoscnze e sui seguenti **DOCUMENTI**:
    
{categories}
"""
    return query, mat_diz



def run_LLM(question, history):
    query, mat = get_query_clean(question, history)
    risposta = query_model(
        query,
        history,
        temperature=0.01,
        max_length=1024
    )
    
    #matches = re.findall(r'\b\d+\b','\n'.join(re.findall(r'\b[Dd]ocumento \d+\b|documenti|documenti forniti', risposta)))
    #testo_agg = ""
    #if len(mat)>0 and len(matches)>0:
    """ for k in mat:
        for i,el in k.items():
            testo_agg += f"DOCUMENTO {i}:\n{el}\n\n" """
    rispost_tot =risposta #+ "\n\n------------------\n\n"+testo_agg
    return rispost_tot




max_chat_length = 10 

def answer_question(question, chat_history):
    if len(chat_history) >= max_chat_length:
        # Se la cronologia è troppo lunga, resetta la chat e mostra un messaggio di avviso
        response = "CHAT TROPPO LUNGA! RICOMINCIARE DI NUOVO."
        chat_history = []  # Azzera la cronologia della chat
    else:
        answers = run_LLM(question, chat_history)
        if answers:
            response = answers  # Restituisce la prima risposta trovata
        else:
            response = "Non ho trovato una risposta alla tua domanda."
        
        chat_history.append((question, response))
        #chat_history=[]
    
    # Restituisci tre output: uno per svuotare la textbox, uno per aggiornare la chat, e uno per aggiornare lo stato
    return "", chat_history, chat_history



# Funzione per resettare la chat
def reset_chat():
    return [], []

# Creazione dell'interfaccia utente personalizzata con gr.Blocks
with gr.Blocks() as demo:
    gr.Markdown("# FiscoLlama")
    gr.Markdown("Benvenuto su FiscoLlama! Fai una domanda riguardante il fisco italiano e ricevi una spiegazione semplice ed esaustiva.")
    
    with gr.Row():
        with gr.Column(scale=1, min_width=100):
            gr.Image("/home/a.alessandrelli/LLM/Hackaton_LLama_ROMA/fiscoLLama_imm.jpeg", label="FiscoLlama Logo", width=50, height=200, show_label=False, show_share_button=False, show_download_button=False, container=False)
        with gr.Column(scale=6):
            chatbox = gr.Chatbot(label="FiscoLlama", show_copy_button=True, avatar_images=("/home/a.alessandrelli/LLM/Hackaton_LLama_ROMA/users.jpg", "/home/a.alessandrelli/LLM/Hackaton_LLama_ROMA/fiscoLLama_imm.jpeg"), show_share_button=True)
            state = gr.State([])  # Stato per memorizzare la cronologia della chat
    
    msg = gr.Textbox(show_label=False, placeholder="Inserisci il tuo messaggio...", container=True)
    btn_send = gr.Button("Invia")
    btn_clear = gr.Button("Pulisci Chat")

    with gr.Row():
        gr.Markdown("### Guida:")
        gr.Markdown("Inserisci la tua domanda e clicca su **Invia**. Dopo ogni domanda, clicca su **Pulisci Chat**.")
    
    # Collegamento dei pulsanti e della textbox alle funzioni
    btn_send.click(answer_question, inputs=[msg, state], outputs=[msg, chatbox, state])
    msg.submit(answer_question, inputs=[msg, state], outputs=[msg, chatbox, state])
    btn_clear.click(reset_chat, outputs=[chatbox, state])

# Avvio dell'interfaccia
url = demo.launch(share=True, inbrowser=True, inline=False)
print(url[2])